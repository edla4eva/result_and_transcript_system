The program requires Windows 8/Windows 10 or higher OS to run
.NET Framework 4.6 or higher required
The recommended screen resolution 1280 x 720 or higher
4GB RAM
Microsoft Excel (2013 or higher) must be installed